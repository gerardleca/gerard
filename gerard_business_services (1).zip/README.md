# Gérard Business Services

**Gérard Business Services** est une entreprise spécialisée dans la **gestion immobilière**, la **vente & achat de parcelles**, ainsi que la **maintenance GSM** à Abomey-Calavi, Bénin.  
Notre objectif est d’apporter des solutions fiables, transparentes et efficaces à nos clients.

---

## 🌍 Nos services

- 🏠 **Gestion locative** : suivi complet des loyers, entretien et valorisation de vos biens.  
- 🌐 **Vente & achat de parcelles** : transactions sécurisées avec accompagnement.  
- 🧹 **Entretien & nettoyage** : pour garder vos espaces propres et agréables.  
- 📱 **Maintenance GSM** : assistance et réparation rapide pour vos téléphones.  

---

## 📞 Contact

- **Téléphone 1 (WhatsApp)** : [+229 01 62 04 50 39](https://wa.me/2290162045039)  
- **Téléphone 2** : +229 01 44 58 70 88  
- **Email** : [gerardbusinessservice@gmail.com](mailto:gerardbusinessservice@gmail.com)  
- **Facebook** : [Gérard Business Services Immobiliers](https://www.facebook.com/gerardbusinessservicesimmobiliers)  
- **Ville** : Abomey-Calavi, Bénin  

---

## 🌐 Site web

👉 [Accéder au site en ligne](https://gerardleca.github.io/gerard_business_services/)

---

⚡ Développé avec ❤️ pour offrir le meilleur des services immobiliers et GSM au Bénin.
